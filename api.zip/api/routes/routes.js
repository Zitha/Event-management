const express = require('express');
const Event = require('../models/event');
const Booking = require('../models/booking');

const { transformEvent } = require('./merge');
const { transformBooking } = require('./merge');

const router = express.Router();

//Get All Events
router.get('/events', async (req, res) => {
    try {
        const events = await Event.find();
        var transformedEvents = events.map(event => { return transformEvent(event); });
        res.json(transformedEvents);
        //res.json(events);
    }
    catch (error) {
        res.status(500).json({ message: error.message })
    }
})

//Get ALl Bookings
router.get('/bookings', async (req, res) => {
    try {
        const data = await Booking.find();
        var transformBookings = data.map(booking => { return transformBooking(booking) });
        res.json(transformBookings)
    }
    catch (error) {
        res.status(500).json({ message: error.message })
    }
})


router.get("/health", async (req, res) => {
    try {
        res.status(200).json({ message: "Api is running..." });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
})
module.exports = router;